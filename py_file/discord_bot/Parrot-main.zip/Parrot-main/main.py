from core import Parrot

bot = Parrot()

if __name__ == "__main__":
    # bot.ipc.start()
    bot.run()
